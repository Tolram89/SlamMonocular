#pragma once
#include <opencv2/core/mat.hpp>
#include <string>

class Camera {
private:
	cv::Mat cameraMatrix;
	cv::Mat distCoeffs;
public:

	[[nodiscard]] bool setIntrinsics(const cv::Mat& k, const cv::Mat& dist);
	bool isCalibrated() const;
	[[nodiscard]] bool loadIntrinsics(const std::string& fileName);
	[[nodiscard]] bool saveIntrinsics(const std::string& fileName) const;
	cv::Mat getCameraMatrix() const;
	cv::Mat getDistCoeffs() const;
};